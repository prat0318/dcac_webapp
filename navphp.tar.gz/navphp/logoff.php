<?php
#---------------------------
# PHP Navigator 4.0
# dated: January 23, 2009
# Coded by: Cyril Sebastian,
# Kerala,India
# web: navphp.sourceforge.net
#---------------------------

      //error_log('dcac_set_maskk: ' . dcac_get_mask());
      //dcac_set_mask(65535);
      //error_log('dcac_set_maskk: ' . dcac_get_mask());

session_start();
session_unset();
session_destroy();
$_SESSION['loggedin'] = 0;
		
header("Location:login.php");
?>
