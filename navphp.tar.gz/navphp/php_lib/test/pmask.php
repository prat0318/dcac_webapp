<?php
  // AD: dl no longer necessary if Makefile used
dl("dcac.so");
$a = dcac_get_mask();
echo $a."\n";
dcac_set_mask(365);
echo dcac_get_mask();
?>

