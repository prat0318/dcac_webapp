<?php

if (dcac_unlock() < 0)
   die("dcac_unlock");

# $rc = dcac_drop_attr('u.65534');
# $rc = dcac_drop_attr('u.65534.user.user1');
# $rc = dcac_drop_attr('g.65534');
// Should be running as nobody, id will show it
system('id');
system('../../bin/show');

$rc = dcac_add_uname_attr(5);
if ($rc < 0)
   die("uname failed\n");

$rc = dcac_add_gname_attr(posix_getgid());
if ($rc < 0)
   die("gname failed\n");

system('../../bin/show');

# $rc = dcac_add_any_attr('foo.bar', DCAC_ADDONLY);
$rc = dcac_add_any_attr('u.'.posix_getuid().'.user.user1', DCAC_ADDONLY);
if ($rc < 0)
   die("dcac_add_any_attr\n");

echo dcac_get_attr_fd("u.65536")."\n";
echo dcac_get_attr_fd("u.".posix_getuid())."\n";

# $foo_fd = dcac_get_attr_fd('foo');
$foo_fd = dcac_get_attr_fd('u.'.posix_getuid());
if ($foo_fd < 0)
   die("dcac_get_attr_fd('foo')\n");

// Should have foo, foo.bar
system('../../bin/show');

# $rc = dcac_drop_attr('foo');
$rc = dcac_drop_attr('u.'.posix_getuid());
if ($rc < 0)
   die("dcac_drop_attr('foo')\n");

// Should only have foo
system('../../bin/show');
