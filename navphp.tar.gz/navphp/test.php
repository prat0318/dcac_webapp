<?php

if (dcac_unlock() < 0)
   die("dcac_unlock");

// Should be running as nobody, id will show it
system('id');
system('bin/show');

$rc = dcac_add_any_attr('foo.bar', DCAC_ADDONLY);
if ($rc < 0)
   die("dcac_add_any_attr\n");

$foo_fd = dcac_get_attr_fd('foo');
if ($foo_fd < 0)
   die("dcac_get_attr_fd('foo')\n");

// Should have foo, foo.bar
system('bin/show');

$rc = dcac_drop_attr('foo');
if ($rc < 0)
   die("dcac_drop_attr('foo')\n");

// Should only have foo
system('bin/show');
