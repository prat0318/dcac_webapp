       #include <sys/types.h>
#include <stdio.h>

int main() {
  int val = open("/var/www/navphp/data/groups/user5", 0);
  if(val < 0) {
      perror("Error: ");
  }
    return val;
}
