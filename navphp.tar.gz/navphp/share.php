<?php
$dir = @$_REQUEST['dir'];
$ajax=@$_REQUEST['ajax'];
$file=@$_REQUEST['file'];
$grpuser = @$_REQUEST['grpuser'];
//$group_name = @$_REQUEST['group_name'];
$perm_changed = @$_REQUEST['perm_changed'];
$loggeduser = @$_SESSION['loggeduser'];
$grpuser=base64_decode($grpuser);
$perm_changed = base64_decode($perm_changed);
//$group_name = base64_decode($group_name);

error_log("<__>SHARE<__>");
error_log("<__>User to be shared with ".$grpuser);
error_log("<__>Shared by ".$loggeduser);
error_log("<__>File in question ".base64_decode($file));
error_log("<__>Permission with which File needs to be shared ".base64_decode($perm_changed));
include_once("config.php");
include_once("functions.php");

error_log("Path whre the groups data will be present".$groups_path);
$reply=0;

authenticate(); //user login
if($GLOBALS['rdonly']) die("|0|Warning: Working in read-only mode!|");
chdir($dir);


if(!$multi_user&&!$enable_login) $msg="Share Feature Not supported in Non Multi User and No login settings!";
else if(!$multi_user&&($user_i==$user)&&$enable_login){
        $msg="Share Feature Not supported in Non Multi User settings!";
}
else if($multi_user){
		error_log("<__>: debugging ");
        mysql_connect($mysql_server,$mysql_user,$mysql_passwd,false) or die("MySQL authentication failure!");
        mysql_query("use $mysql_db");

        $length = 10;
        $randomString = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
        error_log("<__>:random string".$randomString);
        $group_name = $randomString;
        $members=explode( ',', $grpuser);
        $memberAttrs = array();

        foreach ($members as $member) {
            $memberAttrs[] = ".apps.navphp.u.{$member}";
            $result=mysql_query("select * from $mysql_table where user='$member' ");
		    //error_log("=>Query: select * from $mysql_table where user='$grpuser'".$result);
		    if(mysql_num_rows($result)>0){
                error_log("<__>SHARE:Valid User provided as argument in the group");
                /*TODO: Add into ta for loop to be able to insert multiple values in the DB in thr group*/
                $result=mysql_query("insert ignore into $group_table (`user`, `group`, `owner`) values ('$member', '$group_name', '$user') ") or die(mysql_error());
                error_log("<__>: insert ignore into $group_table (`user`, `group`, `owner`) values ('$member', '$group_name', '$user') ");
            }else{
                goto invalid;
            }
        }
        chdir($groups_path);

        $out = array();
        exec("/home/ubuntu/dcac/user/bin/show", $out);
        foreach($out as $line) {
            error_log($line);
        }
        error_log(system('id'));
        if (!posix_access($user, POSIX_F_OK)) {
            if (!mkdir($user, 0)) {
                error_log( "<__>;could not create user group dir ({$user})");
                goto out;
            }
            $user_realpath = realpath($user);
            error_log("---> REAL PATH: $user_realpath");
            $groupDirFD = dcac_open($user_realpath, 0); // O_RDONLY: 0
            if ($groupDirFD < 0) {
                error_log("<__>: could not open user group dir ({$user})");
                goto out;
            }
                
            if (dcac_set_file_exacl($user_realpath, '.apps.navphp.common') < 0) {
                error_log("<__>: could not set perms on user group dir ({$user})");
                goto out;
            }
                
        }
            $userGroupDir = realpath($user);
            /* now the group file (gateway) itself */
            $userGroupFile = $userGroupDir."/{$group_name}";
            error_log("<__>:group file:".$userGroupFile);
            @unlink($userGroupFile);
            
            $userAttr = ".apps.navphp.u.{$user}";
            $groupAttr = "{$userAttr}.g.{$group_name}";
            error_log("<__>:groupAttr:{$groupAttr}");
            if (dcac_add_any_attr($groupAttr, DCAC_ADDMOD) < 0) {
                error_log("<__>: could not add group attribute ({$groupAttr})");
                goto out;
            }

            $attrFD = dcac_get_attr_fd($groupAttr);
            error_log("<__>:attrFD:{$attrFD}");
            $memberAttrs = array();
            foreach ($members as $member) {
                $memberAttrs[] = ".apps.navphp.u.{$member}";
            }
            $memberAttrs[] = ".apps.navphp.u.{$user}";
            $groupACL = join('|',$memberAttrs);
            error_log("<__>:group ACL: {$groupACL}");
            
            /* create the file for the group */
            ini_set('track_errors', 1);
            if (!($f = fopen($userGroupFile, "w"))) {
                error_log("<__>: could not create group file ({$userGroupFile}) $php_errormsg");
                goto out;
            }
            fclose($f);
            if (!($f = dcac_open($userGroupFile, 0))) {
                error_log("<__>: could not read the group's file ({$userGroupFile}) $php_errormsg");
                goto out;
            }
            if (dcac_set_attr_acl($attrFD,$f, $groupACL, $userAttr) < 0) {
                error_log('<__>: could not set permissions on the gateway file');
                goto out_drop;
            }
            /* Need to be able to read file to open it */
            if (dcac_set_file_rdacl($userGroupFile, $groupACL) < 0){
                error_log('<__>: could not change perms on gateway file');
                goto out_drop;
            }

            $filepath=$dir.'/'.$file;
            error_log("<__>:filepath:'$filepath'");
            error_log("<__>:permission:'$perm_changed[0]'"); 
            if($perm_changed[0]=='1'){
                error_log("Changing the read acl");
                if(dcac_set_file_rdacl($filepath, $groupACL)<0){
                    error_log('<__>: could not set premission on the file');
                    goto out;
                }
            }
            if($perm_changed[1]=='1'){
                if(dcac_set_file_wracl($filepath, $groupACL)<0){
                    error_log('<__>: could not set premission on the file');
                    goto out;
                }
            }
            if($perm_changed[2]=='1'){
                if(dcac_set_file_exacl($filepath, $groupACL)<0){
                    error_log('<__>: could not set premission on the file');
                    goto out;
                }
            }
            if($perm_changed[3]=='1'){
                if(dcac_set_file_mdacl($filepath, $groupACL)<0){
                    error_log('<__>: could not set premission on the file');
                    goto out;
                }
            }
            $msg ="Group Created successfully";
            $reply=1;
            goto success;
            out_drop:
            out:
                if (dcac_drop_attr($groupAttr) < 0) {
                    error_log('<__>: could not drop group attribute');
                }
                  if ($f >= 0) {
                     dcac_close($f);
                  }
                  if ($groupDirFD >= 0) {
                     dcac_close($groupDirFD);
                  }
                if(!$reply) {
                    $reply=-1;
                    $msg="Error while setting group permissions the group";
                }
            goto success;
            invalid:
            $reply=-1;
			$msg="Invalid User!!";
}
success:
if($ajax){
    expired();
    print"|$reply|$msg|";
    if($reply) filestatus($file)."|";
}
?>
