<script>
if (window.XMLHttpRequest||window.ActiveXObject) 
	document.cookie="navphp=ajax";
else	document.cookie="navphp=normal";

if(screen.width>1024) document.cookie="navphp_cols=9";
else if(screen.width>800) document.cookie="navphp_cols=7";
else document.cookie="navphp_cols=5";
window.location.href="windows.php";
</script>